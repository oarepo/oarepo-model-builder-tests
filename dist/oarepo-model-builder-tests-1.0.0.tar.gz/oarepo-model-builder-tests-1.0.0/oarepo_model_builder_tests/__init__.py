TEMPLATES = {
    "conftest": "templates/conftest.py.jinja2",
    "test_resource": "templates/test_resource.py.jinja2",
    "test_service": "templates/test_service.py.jinja2",
}