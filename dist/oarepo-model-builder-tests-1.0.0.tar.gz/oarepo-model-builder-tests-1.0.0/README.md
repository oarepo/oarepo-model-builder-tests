# OARepo model builder tests
Plugin ("wrapper") for oarepo-model-builder to generate 
test files and update the dependencies along with the model. <br>
The record service and its rest api are covered for now. Tests read, write,
update, delete and search operations.